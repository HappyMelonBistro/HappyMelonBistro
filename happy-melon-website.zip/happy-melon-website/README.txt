Happy Melon Bistro — Free & Easy Website
========================================

This is a simple, single‑page website you can host for free.

1) Edit your details
--------------------
Open index.html and update:
- Phone / WhatsApp numbers (search for 1868XXXXXXX)
- Social links in the footer
- Menu items, prices, hours, address
- Email in script.js (search for hello@example.com)
- Replace images in /assets with your own JPG/PNG files. Keep the same names or change the src in index.html.

2) Host it for FREE (choose one)
--------------------------------

Option A — GitHub Pages (free, reliable)
- Create a GitHub account.
- New repository named: happy-melon-bistro (any name is fine).
- Upload all files in this folder (index.html, styles.css, script.js, assets).
- Go to Settings → Pages → Deploy from branch → Select "main" and "/" root → Save.
- Wait ~1 minute. Your site will appear at: https://<your-username>.github.io/<repo-name>/

Option B — Netlify (free, super easy)
- Create a Netlify account.
- Drag‑and‑drop this whole folder into the "Sites" page.
- Netlify gives you a free .netlify.app URL instantly.
- You can connect a custom domain later if you want.

Option C — Cloudflare Pages (free, fast)
- Create a Cloudflare account → Pages → Upload assets → Drop this folder.
- Get a free .pages.dev URL.

3) Edit on your phone (quick hacks)
-----------------------------------
- Use a free code editor app (e.g., "Acode" on Android) to open and edit files.
- Replace images in /assets with your camera photos using the same filenames.
- Re‑zip and upload again to your host.

4) Custom domain (optional)
---------------------------
- Buy a domain (Namecheap, Google Domains transfer, etc.), then follow your host's instructions to connect it.
- Tip: Set your domain's root (Apex) and 'www' to your host as their docs say.

5) Need more pages?
-------------------
- Duplicate index.html, rename to e.g. menu.html, and update the links in the header.
- Keep styles.css and script.js shared.

6) Contact form (no backend)
----------------------------
- The form opens your email app (mailto). For a real inbox form, you can add a free service like Formspree or Netlify Forms later.

Have fun and good luck!
